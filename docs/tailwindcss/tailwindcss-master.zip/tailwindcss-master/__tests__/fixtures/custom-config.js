module.exports = {
  theme: {
    screens: {
      mobile: '400px',
    },
  },
}
