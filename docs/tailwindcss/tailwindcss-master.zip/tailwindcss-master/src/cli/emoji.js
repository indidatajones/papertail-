import { get } from 'node-emoji'

export const yes = get('white_check_mark')
export const no = get('no_entry_sign')
export const go = get('rocket')
export const pack = get('package')
export const disk = get('floppy_disk')
